---
name: "Crown & Blade — Luxury Grooming & Barberia"
description: "Dark-mode vintage-modern luxury design system combining deep matte black surfaces, brushed gold accents, and authoritative editorial serif typography."
---

## Overview

Crown & Blade is a luxury barbershop, booking destination, and professional grooming supply storefront. The visual language blends classic barbershop heritage—tactile brass, honed steel, and apothecary glass—with sleek contemporary dark-mode e-commerce.

- **Audience:** Discerning gentlemen seeking bespoke grooming services and master barbers sourcing studio-grade clippers, Japanese steel shears, and straight razors.
- **Design Style:** Dark-mode editorial luxury with high-contrast focal photography, warm gold metallic accents, and disciplined geometric grids.
- **Mood:** Authoritative, masculine, crafted, and unhurried.

## Colors

The palette anchors on a deep matte black canvas (`#121212`) paired with charcoal grey cards (`#1E1E1E`) to eliminate harsh pure-black halation. Rich Gold (`#D4AF37`) is reserved for primary calls to action, active states, and premium badges, while Warm Cream (`#F5F5F5`) ensures crisp readability.

- **Primary (`#D4AF37`):** Rich Gold/Amber for primary CTAs, active selections, and luxury accents. Always paired with deep matte black (`#121212`) text.
- **Surface (`#121212`) & Surface Container (`#1E1E1E`):** Matte black page ground and elevated charcoal cards, separated by subtle warm-taupe hairline borders (`#363020`).
- **On-Surface (`#F5F5F5`) & On-Surface Variant (`#ADABAA`):** Warm cream for primary copy and muted pewter for specs, metadata, and secondary labels.

```yaml
colors:
  primary: "#D4AF37"
  on-primary: "#121212"
  primary-hover: "#E9C349"
  primary-container: "#3C2F00"
  on-primary-container: "#FFE088"
  secondary: "#BEAA74"
  on-secondary: "#121212"
  secondary-container: "#3C2F05"
  on-secondary-container: "#F7E1A6"
  surface: "#121212"
  on-surface: "#F5F5F5"
  surface-container-low: "#181818"
  surface-container: "#1E1E1E"
  surface-container-high: "#2A2929"
  surface-container-highest: "#363535"
  on-surface-variant: "#ADABAA"
  outline: "#4D4635"
  outline-variant: "#363020"
  success: "#81C784"
  on-success: "#121212"
  error: "#FFB4AB"
  on-error: "#410002"
  error-container: "#93000A"
  on-error-container: "#FFDAD6"
```

## Typography

A disciplined dual-font pairing balances heritage authority with technical product clarity. **Playfair Display** brings classic editorial gravitas to headlines and section titles, **Inter** delivers crisp legibility for navigation and product descriptions, and **JetBrains Mono** aligns pricing, ratings, and tool specifications with `tabular-nums`.

```yaml
typography:
  display-lg:
    fontFamily: "Playfair Display"
    fontSize: 56px
    fontWeight: 700
    lineHeight: 62px
    letterSpacing: -0.5px
  display-lg-mobile:
    fontFamily: "Playfair Display"
    fontSize: 32px
    fontWeight: 700
    lineHeight: 38px
    letterSpacing: -0.25px
  display-md:
    fontFamily: "Playfair Display"
    fontSize: 44px
    fontWeight: 700
    lineHeight: 50px
    letterSpacing: -0.25px
  display-md-mobile:
    fontFamily: "Playfair Display"
    fontSize: 28px
    fontWeight: 700
    lineHeight: 34px
    letterSpacing: -0.2px
  headline-lg:
    fontFamily: "Playfair Display"
    fontSize: 36px
    fontWeight: 600
    lineHeight: 44px
    letterSpacing: 0px
  headline-lg-mobile:
    fontFamily: "Playfair Display"
    fontSize: 24px
    fontWeight: 600
    lineHeight: 30px
    letterSpacing: 0px
  headline-md:
    fontFamily: "Playfair Display"
    fontSize: 28px
    fontWeight: 600
    lineHeight: 34px
    letterSpacing: 0px
  headline-sm:
    fontFamily: "Playfair Display"
    fontSize: 22px
    fontWeight: 600
    lineHeight: 28px
    letterSpacing: 0px
  title-lg:
    fontFamily: "Inter"
    fontSize: 18px
    fontWeight: 600
    lineHeight: 24px
    letterSpacing: 0px
  title-md:
    fontFamily: "Inter"
    fontSize: 16px
    fontWeight: 600
    lineHeight: 22px
    letterSpacing: 0px
  body-lg:
    fontFamily: "Inter"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 24px
    letterSpacing: 0px
  body-md:
    fontFamily: "Inter"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 21px
    letterSpacing: 0px
  body-sm:
    fontFamily: "Inter"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 18px
    letterSpacing: 0.1px
  label-lg:
    fontFamily: "Inter"
    fontSize: 14px
    fontWeight: 600
    lineHeight: 20px
    letterSpacing: 0.5px
  label-md:
    fontFamily: "Inter"
    fontSize: 12px
    fontWeight: 600
    lineHeight: 16px
    letterSpacing: 0.5px
  label-sm:
    fontFamily: "Inter"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 16px
    letterSpacing: 0.6px
  mono-md:
    fontFamily: "JetBrains Mono"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 20px
    letterSpacing: 0px
  mono-sm:
    fontFamily: "JetBrains Mono"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 16px
    letterSpacing: 0.2px
```

## Layout & Spacing

The storefront uses a **12-column Fixed-Max-Width Grid** (`max-w-7xl` / `1280px` container) with generous `24px` to `32px` gutters on desktop and a fluid single-column stack on mobile. A strict `4px` / `8px` spacing scale separates internal component padding from macro section rhythms.

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 16px
  gutter-lg: 24px
  gutter-xl: 32px
  section: 64px
  page-margin: 24px
```

## Elevation & Depth

Hierarchy relies on **tonal layering paired with low-contrast hairline borders** rather than heavy drop shadows, which vanish against dark backgrounds.

- Page ground sits at `surface` (`#121212`), cards sit at `surface-container` (`#1E1E1E`) with a `1px` `outline-variant` (`#363020`) border, and interactive hover states step up to `surface-container-high` (`#2A2929`) with `outline` (`#4D4635`) or `primary` (`#D4AF37`) borders.
- Sticky navigation and slide-out drawers use solid `surface-container-low` (`#181818`) or `surface` (`#121212`) with crisp bottom/side `outline-variant` borders.

## Shapes

The shape language is **tailored and architectural**—crisp, restrained corner radii that evoke precision-machined grooming instruments rather than soft consumer apps.

```yaml
rounded:
  sm: 4px
  DEFAULT: 6px
  md: 8px
  lg: 12px
  xl: 16px
  full: 9999px
```

## Motion & Micro-interaction

Motion is deliberate, weighted, and mechanical. Interactive controls respond immediately (`150ms`), image zoom hovers on category and product cards glide smoothly (`300ms`), and slide-out drawers decelerate cleanly. Only `transform`, `opacity`, and `color` properties are animated, respecting `prefers-reduced-motion`.

```yaml
motion:
  state-change:
    duration: 150ms
    delay: 0ms
    timingFunction: ease-out
  card-zoom:
    duration: 300ms
    delay: 0ms
    timingFunction: cubic-bezier(0.2, 0, 0, 1)
  drawer-enter:
    duration: 280ms
    delay: 0ms
    timingFunction: cubic-bezier(0.2, 0, 0, 1)
```

## Voice & Content Strategy

- **Tone of voice:** Confident, craft-obsessed, and concise. Speaks like a master barber advising a fellow professional or discerning client—never salesy or hyperbolic.
- **Capitalisation:** Title Case for primary navigation, section headlines, and product titles; Sentence case for descriptions and specifications; Uppercase with wide tracking for brand badges and category eyebrows.
- **Button and action labels:** Direct verb phrases (`Shop Pro Tools`, `Book Appointment`, `Add to Cart`, `Build Custom Kit`, `Quick View`).
- **Numbers & currency:** USD formatted with two decimals (`$249.00`) or clean integer for bundles, always styled with `tabular-nums`.

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Badge** → `@components/badge.html` — `badge-numeric`, `badge-dot`
- **Button** → `@components/button.html` — `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html` — `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Modal** → `@components/modal.html` — `modal-standard`, `modal-alert`, `modal-drawer`
